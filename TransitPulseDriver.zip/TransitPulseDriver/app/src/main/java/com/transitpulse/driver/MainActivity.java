package com.transitpulse.driver;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import io.socket.client.IO;
import io.socket.client.Socket;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "TransitPulse";
    private static final int    PERM_CODE = 1001;
    private static final String BACKEND_URL = "https://hack-b95s.onrender.com";
    private static final long   INTERVAL_MS = 3000L;

    // UI
    private TextView tvConnection, tvStatus, tvLat, tvLng, tvSpeed,
                     tvAccuracy, tvCurrentStop, tvNextStop, tvETA, tvRoute;
    private Button   btnStart, btnStop;
    private Spinner  spinnerRoute, spinnerSource, spinnerDest;
    private LinearLayout layoutSetup, layoutLive;

    // Location
    private FusedLocationProviderClient fusedClient;
    private LocationCallback locationCallback;
    private boolean isTracking = false;
    private double  lat = 0, lng = 0;
    private float   speed = 0, accuracy = 0;

    // Socket
    private Socket socket;

    // Route state
    private int routeIdx    = 0;
    private int srcIdx      = 0;
    private int dstIdx      = 0;
    private int curStopIdx  = 0;

    // ── Sambhaji Nagar (Chhatrapati Sambhajinagar) city bus routes ────────────
    // Format: { "Display Name", "RouteID" }
    private static final String[][] ROUTES = {
        { "BUS-01  CIDCO → CBS",          "BUS-01" },
        { "BUS-02  Satara → Airport",      "BUS-02" },
        { "BUS-03  Garkheda → BAMU",       "BUS-03" },
        { "BUS-04  Bajaj Nagar → MIDC",    "BUS-04" },
        { "BUS-05  Padampura → Waluj",     "BUS-05" },
    };

    // [routeIdx][stopIdx] = { "Stop Name", lat, lng }
    private static final Object[][][] STOPS = {
        // BUS-01: CIDCO → CBS  (central area)
        {
            { "CIDCO Bus Stand",         19.8856, 75.3318 },
            { "CIDCO N-6 Chowk",         19.8821, 75.3391 },
            { "Prozone Mall",            19.8784, 75.3455 },
            { "Aurangabad Railway Station", 19.8762, 75.3507 },
            { "Gulmandi",                19.8748, 75.3561 },
            { "Mondha Naka",             19.8735, 75.3593 },
            { "CBS (Central Bus Stand)", 19.8726, 75.3624 },
        },
        // BUS-02: Satara → Airport
        {
            { "Satara Parisar",          19.8520, 75.3010 },
            { "Cantonment",              19.8600, 75.3102 },
            { "Osmanpura",               19.8690, 75.3214 },
            { "Padampura Chowk",         19.8712, 75.3352 },
            { "Bhavsinghpura",           19.8668, 75.3607 },
            { "Chikalthana",             19.8650, 75.3810 },
            { "Aurangabad Airport",      19.8632, 75.3972 },
        },
        // BUS-03: Garkheda → BAMU
        {
            { "Garkheda Bus Stop",       19.8390, 75.3770 },
            { "Hudco Colony",            19.8432, 75.3692 },
            { "Jalna Road Chowk",        19.8503, 75.3622 },
            { "Bansilal Nagar",          19.8563, 75.3553 },
            { "Nirala Bazar",            19.8590, 75.3510 },
            { "BAMU University",         19.8621, 75.3481 },
        },
        // BUS-04: Bajaj Nagar → MIDC
        {
            { "Bajaj Nagar",             19.8960, 75.3200 },
            { "Mukundwadi Corner",       19.8882, 75.3402 },
            { "Chikalthana Colony",      19.8801, 75.3625 },
            { "Waluj T-Point",           19.8712, 75.3855 },
            { "Waluj Phase-1",           19.8671, 75.3980 },
            { "MIDC Waluj",              19.8622, 75.4108 },
        },
        // BUS-05: Padampura → Waluj
        {
            { "Padampura",               19.8712, 75.3352 },
            { "Kranti Chowk",            19.8700, 75.3420 },
            { "Osmanpura X-Road",        19.8689, 75.3530 },
            { "Aurangpura",              19.8660, 75.3614 },
            { "Harsul T-Point",          19.8630, 75.3720 },
            { "Waluj MIDC Gate",         19.8610, 75.4050 },
        },
    };

    // ─────────────────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        initSocket();
        fusedClient = LocationServices.getFusedLocationProviderClient(this);
        buildLocationCallback();
        setupRouteSpinners();
        setupButtons();
    }

    private void bindViews() {
        tvConnection  = findViewById(R.id.tvConnection);
        tvStatus      = findViewById(R.id.tvStatus);
        tvLat         = findViewById(R.id.tvLatitude);
        tvLng         = findViewById(R.id.tvLongitude);
        tvSpeed       = findViewById(R.id.tvSpeed);
        tvAccuracy    = findViewById(R.id.tvAccuracy);
        tvCurrentStop = findViewById(R.id.tvCurrentStop);
        tvNextStop    = findViewById(R.id.tvNextStop);
        tvETA         = findViewById(R.id.tvETA);
        tvRoute       = findViewById(R.id.tvRoute);
        btnStart      = findViewById(R.id.btnStart);
        btnStop       = findViewById(R.id.btnStop);
        spinnerRoute  = findViewById(R.id.spinnerRoute);
        spinnerSource = findViewById(R.id.spinnerSource);
        spinnerDest   = findViewById(R.id.spinnerDest);
        layoutSetup   = findViewById(R.id.layoutSetup);
        layoutLive    = findViewById(R.id.layoutLive);
    }

    // ── Socket ────────────────────────────────────────────────────────────────

    private void initSocket() {
        try {
            IO.Options o = new IO.Options();
            o.reconnection = true;
            o.reconnectionAttempts = Integer.MAX_VALUE;
            o.reconnectionDelay = 2000;
            o.timeout = 10000;
            socket = IO.socket(BACKEND_URL, o);
            socket.on(Socket.EVENT_CONNECT,       a -> runOnUiThread(() -> {
                tvConnection.setText("🟢 Connected");
                tvConnection.setTextColor(getCol(R.color.green));
                Toast.makeText(this, "Connected to server", Toast.LENGTH_SHORT).show();
            }));
            socket.on(Socket.EVENT_DISCONNECT,    a -> runOnUiThread(() -> {
                tvConnection.setText("🔴 Disconnected");
                tvConnection.setTextColor(getCol(R.color.red));
            }));
            socket.on(Socket.EVENT_CONNECT_ERROR, a -> runOnUiThread(() -> {
                tvConnection.setText("⚠️ Retrying…");
                tvConnection.setTextColor(getCol(R.color.orange));
            }));
            socket.connect();
        } catch (URISyntaxException e) {
            Log.e(TAG, "Socket URL error: " + e.getMessage());
        }
    }

    // ── Spinners ──────────────────────────────────────────────────────────────

    private void setupRouteSpinners() {
        List<String> rNames = new ArrayList<>();
        for (String[] r : ROUTES) rNames.add(r[0]);
        spinnerRoute.setAdapter(makeAdapter(rNames));
        spinnerRoute.setOnItemSelectedListener(new SimpleSelect() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                routeIdx = pos;
                refreshSourceDest();
            }
        });
        refreshSourceDest();
    }

    private void refreshSourceDest() {
        Object[][] s = STOPS[routeIdx];
        List<String> names = new ArrayList<>();
        for (Object[] stop : s) names.add((String) stop[0]);
        ArrayAdapter<String> a = makeAdapter(names);
        spinnerSource.setAdapter(a);
        spinnerDest.setAdapter(a);
        spinnerSource.setSelection(0);
        spinnerDest.setSelection(names.size() - 1);
        srcIdx = 0; dstIdx = names.size() - 1;

        spinnerSource.setOnItemSelectedListener(new SimpleSelect() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                srcIdx = pos;
            }
        });
        spinnerDest.setOnItemSelectedListener(new SimpleSelect() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                dstIdx = pos;
            }
        });
    }

    // ── Buttons ───────────────────────────────────────────────────────────────

    private void setupButtons() {
        btnStart.setOnClickListener(v -> {
            if (srcIdx >= dstIdx) {
                Toast.makeText(this, "Destination must be after source!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!hasPerm()) reqPerm();
            else if (!gpsOn()) showGpsDialog();
            else startTracking();
        });
        btnStop.setOnClickListener(v -> stopTracking());
    }

    @SuppressWarnings("MissingPermission")
    private void startTracking() {
        if (isTracking) return;
        curStopIdx = srcIdx;

        fusedClient.requestLocationUpdates(
            new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, INTERVAL_MS)
                .setMinUpdateIntervalMillis(INTERVAL_MS)
                .setWaitForAccurateLocation(false)
                .build(),
            locationCallback, Looper.getMainLooper());

        isTracking = true;
        layoutSetup.setVisibility(View.GONE);
        layoutLive.setVisibility(View.VISIBLE);

        String rName = ROUTES[routeIdx][0];
        tvRoute.setText(rName);
        tvStatus.setText("🟢 Live Tracking");
        tvStatus.setTextColor(getCol(R.color.green));
        btnStart.setEnabled(false);
        btnStop.setEnabled(true);

        emitTripStart();
        Toast.makeText(this, "Tracking Started", Toast.LENGTH_SHORT).show();
    }

    private void stopTracking() {
        if (!isTracking) return;
        fusedClient.removeLocationUpdates(locationCallback);
        isTracking = false;

        layoutSetup.setVisibility(View.VISIBLE);
        layoutLive.setVisibility(View.GONE);

        tvStatus.setText("🔴 Stopped");
        tvStatus.setTextColor(getCol(R.color.red));
        btnStart.setEnabled(true);
        btnStop.setEnabled(false);

        emitTripEnd();
        Toast.makeText(this, "Tracking Stopped", Toast.LENGTH_SHORT).show();
    }

    // ── Location Callback ─────────────────────────────────────────────────────

    private void buildLocationCallback() {
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult r) {
                android.location.Location loc = r.getLastLocation();
                if (loc == null) return;
                lat = loc.getLatitude(); lng = loc.getLongitude();
                speed = loc.getSpeed(); accuracy = loc.getAccuracy();
                advanceStop();
                refreshLiveUI();
                emitLocation();
            }
        };
    }

    // ── Stop Advancement ─────────────────────────────────────────────────────

    private void advanceStop() {
        if (curStopIdx >= dstIdx) return;
        Object[] next = STOPS[routeIdx][curStopIdx];
        float[] res = new float[1];
        android.location.Location.distanceBetween(
            lat, lng, (double) next[1], (double) next[2], res);
        if (res[0] < 120) curStopIdx++;   // within 120m → mark arrived
    }

    private String curStopName() {
        int i = Math.max(srcIdx, curStopIdx == srcIdx ? srcIdx : curStopIdx - 1);
        return (String) STOPS[routeIdx][i][0];
    }

    private String nextStopName() {
        if (curStopIdx >= dstIdx) return (String) STOPS[routeIdx][dstIdx][0] + " ✅ Final";
        return (String) STOPS[routeIdx][curStopIdx][0];
    }

    private int stopsLeft() { return Math.max(0, dstIdx - curStopIdx); }

    private int etaMinutes() {
        int idx = Math.min(curStopIdx, dstIdx);
        Object[] next = STOPS[routeIdx][idx];
        float[] res = new float[1];
        android.location.Location.distanceBetween(
            lat, lng, (double) next[1], (double) next[2], res);
        float spd = (speed > 0.5f) ? speed : (20f / 3.6f);  // default 20 km/h
        return (int) Math.ceil(res[0] / spd / 60f);
    }

    // ── Live UI refresh ───────────────────────────────────────────────────────

    private void refreshLiveUI() {
        tvLat.setText(String.format("%.6f", lat));
        tvLng.setText(String.format("%.6f", lng));
        tvSpeed.setText(String.format("%.1f km/h", speed * 3.6f));
        tvAccuracy.setText(String.format("%.0f m", accuracy));
        tvCurrentStop.setText(curStopName());
        tvNextStop.setText(nextStopName());

        int eta = etaMinutes();
        int left = stopsLeft();
        if (left == 0) tvETA.setText("✅ Arrived at destination");
        else tvETA.setText(eta + " min  •  " + left + " stop" + (left > 1 ? "s" : "") + " left");
    }

    // ── Socket Emits ─────────────────────────────────────────────────────────

    private void emitTripStart() {
        if (!sockOk()) return;
        try {
            JSONArray stopsArr = new JSONArray();
            for (int i = srcIdx; i <= dstIdx; i++) {
                Object[] s = STOPS[routeIdx][i];
                JSONObject st = new JSONObject();
                st.put("name", s[0]); st.put("lat", s[1]); st.put("lng", s[2]);
                stopsArr.put(st);
            }
            JSONObject d = new JSONObject();
            d.put("routeId",    ROUTES[routeIdx][1]);
            d.put("routeName",  ROUTES[routeIdx][0].trim());
            d.put("source",     STOPS[routeIdx][srcIdx][0]);
            d.put("destination",STOPS[routeIdx][dstIdx][0]);
            d.put("totalStops", dstIdx - srcIdx + 1);
            d.put("stops",      stopsArr);
            socket.emit("tripStart", d);
            Log.d(TAG, "tripStart: " + d);
        } catch (Exception e) { Log.e(TAG, e.getMessage()); }
    }

    private void emitLocation() {
        if (!sockOk()) return;
        try {
            JSONObject d = new JSONObject();
            d.put("lat",              lat);
            d.put("lng",              lng);
            d.put("speed",            speed);
            d.put("accuracy",         accuracy);
            d.put("routeId",          ROUTES[routeIdx][1]);
            d.put("routeName",        ROUTES[routeIdx][0].trim());
            d.put("source",           STOPS[routeIdx][srcIdx][0]);
            d.put("destination",      STOPS[routeIdx][dstIdx][0]);
            d.put("currentStop",      curStopName());
            d.put("nextStop",         nextStopName());
            d.put("stopsRemaining",   stopsLeft());
            d.put("etaMinutes",       etaMinutes());
            d.put("currentStopIndex", curStopIdx);
            d.put("totalStops",       dstIdx - srcIdx + 1);
            socket.emit("locationUpdate", d);
            Log.d(TAG, "locationUpdate: lat=" + lat + " next=" + nextStopName());
        } catch (Exception e) { Log.e(TAG, e.getMessage()); }
    }

    private void emitTripEnd() {
        if (!sockOk()) return;
        try {
            JSONObject d = new JSONObject();
            d.put("routeId", ROUTES[routeIdx][1]);
            d.put("event", "tripEnd");
            socket.emit("tripEnd", d);
        } catch (Exception e) { Log.e(TAG, e.getMessage()); }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private boolean sockOk() { return socket != null && socket.connected(); }

    private int getCol(int id) { return ContextCompat.getColor(this, id); }

    private ArrayAdapter<String> makeAdapter(List<String> items) {
        ArrayAdapter<String> a = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, items);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return a;
    }

    // ── Permissions ───────────────────────────────────────────────────────────

    private boolean hasPerm() {
        return ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void reqPerm() {
        ActivityCompat.requestPermissions(this,
                new String[]{ Manifest.permission.ACCESS_FINE_LOCATION,
                              Manifest.permission.ACCESS_COARSE_LOCATION }, PERM_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] p, @NonNull int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (code == PERM_CODE) {
            if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) {
                if (gpsOn()) startTracking(); else showGpsDialog();
            } else {
                Toast.makeText(this, "Permission denied.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private boolean gpsOn() {
        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        return lm != null && lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    private void showGpsDialog() {
        new AlertDialog.Builder(this)
            .setTitle("GPS Disabled")
            .setMessage("Enable GPS to start tracking.")
            .setPositiveButton("Settings", (d, w) ->
                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)))
            .setNegativeButton("Cancel", null).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isTracking) fusedClient.removeLocationUpdates(locationCallback);
        if (socket != null) { socket.disconnect(); socket.off(); }
    }

    // ── Simple spinner listener base class ────────────────────────────────────
    static abstract class SimpleSelect implements AdapterView.OnItemSelectedListener {
        @Override public void onNothingSelected(AdapterView<?> p) {}
    }
}
